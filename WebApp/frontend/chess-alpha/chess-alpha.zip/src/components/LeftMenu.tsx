import React from 'react'
import './LeftMenu.scss'

export interface LeftMenuProps{

}

const LeftMenu: React.FC<LeftMenuProps> = ({}) => {
  return (
    <div className='left-menu'>
        LeftMenu
    </div>
  )
}

export default LeftMenu