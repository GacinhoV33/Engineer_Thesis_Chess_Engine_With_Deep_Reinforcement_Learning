import React from 'react'


export interface HeaderProps{

}

export const Header: React.FC<HeaderProps> = ({}) => {
  return (
    <div>
        Header
    </div>
  )
}
